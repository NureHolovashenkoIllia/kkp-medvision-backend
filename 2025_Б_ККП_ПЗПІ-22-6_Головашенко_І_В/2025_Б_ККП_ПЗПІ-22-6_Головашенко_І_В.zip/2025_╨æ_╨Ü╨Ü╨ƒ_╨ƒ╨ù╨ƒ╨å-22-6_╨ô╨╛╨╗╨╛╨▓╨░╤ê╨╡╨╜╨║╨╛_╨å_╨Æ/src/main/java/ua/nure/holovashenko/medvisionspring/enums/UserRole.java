package ua.nure.holovashenko.medvisionspring.enums;

public enum UserRole {
    DOCTOR,
    PATIENT,
    ADMIN
}