package ua.nure.holovashenko.medvisionspring.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}