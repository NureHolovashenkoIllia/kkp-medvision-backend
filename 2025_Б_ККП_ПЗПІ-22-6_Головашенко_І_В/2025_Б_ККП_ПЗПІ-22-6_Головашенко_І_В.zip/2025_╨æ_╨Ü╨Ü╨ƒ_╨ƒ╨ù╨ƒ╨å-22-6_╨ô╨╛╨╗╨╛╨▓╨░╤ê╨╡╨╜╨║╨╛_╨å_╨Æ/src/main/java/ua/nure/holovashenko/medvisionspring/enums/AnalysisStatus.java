package ua.nure.holovashenko.medvisionspring.enums;

public enum AnalysisStatus {
    PENDING,
    REVIEWED,
    REQUIRES_REVISION
}