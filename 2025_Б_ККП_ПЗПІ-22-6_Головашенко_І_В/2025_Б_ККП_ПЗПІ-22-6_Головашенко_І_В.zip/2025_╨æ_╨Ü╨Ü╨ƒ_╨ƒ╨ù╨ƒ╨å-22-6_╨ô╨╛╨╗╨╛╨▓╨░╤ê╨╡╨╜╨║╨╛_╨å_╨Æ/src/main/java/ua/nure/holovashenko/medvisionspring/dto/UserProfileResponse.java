package ua.nure.holovashenko.medvisionspring.dto;

public interface UserProfileResponse {}
